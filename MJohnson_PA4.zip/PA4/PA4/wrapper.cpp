#include "wrapper.h"

/************************************************************
Pre:
Post:
* Description:     This function is the default constructor for appwrapper.
* Returns:
*************************************************************/
AppWrapper::AppWrapper(DietPlan dp[7], FitnessPlan fp[7])
{
	//empty, already init
}

/************************************************************
Pre:
Post:
* Description:     This function is the default constructor for appwrapper.
* Returns:
*************************************************************/
AppWrapper::AppWrapper()
{
	
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function loads a daily plan.
* Returns:
*************************************************************/
void AppWrapper::loadDailyDP(fstream &filein, DietPlan &dplan)
{
	filein >> dplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function loads a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::loadWeeklyDP(fstream &filein, DietPlan dplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		loadDailyDP(filein, dplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function loads a daily plan.
* Returns:
*************************************************************/
void AppWrapper::loadDailyFP(fstream &filein, FitnessPlan &fplan)
{
	filein >> fplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function loads a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::loadWeeklyFP(fstream &filein, FitnessPlan fplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		loadDailyFP(filein, fplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function stores a daily plan.
* Returns:
*************************************************************/
void AppWrapper::storeDailyDP(ofstream &fileout, DietPlan &dplan)
{
	fileout << dplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function stores a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::storeWeeklyDP(ofstream &fileout, DietPlan dplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		storeDailyDP(fileout, dplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function stores a plan.
* Returns:
*************************************************************/
void AppWrapper::storeDailyFP(ofstream &fileout, FitnessPlan &fplan)
{
	fileout << fplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function stores a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::storeWeeklyFP(ofstream &fileout, FitnessPlan fplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		storeDailyFP(fileout, fplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function prints a plan.
* Returns:
*************************************************************/
void AppWrapper::dispDailyDP(DietPlan &dplan)
{
	cout << dplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function prints a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::dispWeeklyDP(DietPlan dplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		dispDailyDP(dplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function prints a plan.
* Returns:
*************************************************************/
void AppWrapper::dispDailyFP(FitnessPlan &fplan)
{
	cout << fplan;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function prints a weekly plan.
* Returns:
*************************************************************/
void AppWrapper::dispWeeklyFP(FitnessPlan fplan[])
{
	int fileplanindex = 0;

	while (fileplanindex < 7)
	{
		dispDailyFP(fplan[fileplanindex]);
		fileplanindex++;
	}
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function edits a plan by asking for a new calorie goal.
* Returns:
*************************************************************/
void AppWrapper::editDailyDP(DietPlan dplan[])
{
	int choice = 0;
	int iterator = 0;
	

	cout << "You may edit the following plans.\nTo choose a plan, type its corresponding number." << endl;
	while (iterator < 7)
	{
		cout << iterator << "\n" << dplan[iterator] << endl;
		iterator++;
	}

	do
	{
		cin >> choice;
	} while ((choice < 1) && (choice >7));
	dplan[choice].DPplanEditor(dplan[choice]);

	cout << "Your change has been saved." << endl;
}

/************************************************************
Pre: dependent on other functions and overloaded operators
Post:
* Description:     This function edits a plan by asking for a new calorie goal.
* Returns:
*************************************************************/
void AppWrapper::editDailyFP(FitnessPlan fplan[])
{
	int choice = 0;
	int iterator = 0;


	cout << "You may edit the following plans.\nTo choose a plan, type its corresponding number." << endl;
	while (iterator < 7)
	{
		cout << iterator << "\n" << fplan[iterator] << endl;
		iterator++;
	}

	do
	{
		cin >> choice;
	} while ((choice < 1) && (choice >7));
	fplan[choice].FPplanEditor(fplan[choice]);

	cout << "Your change has been saved." << endl;
}

/*************************************************************
* Overloaded Operator: ostream &operator<<(ostream &lhs, const FitnessPlan &rhs)
* Date Last Modified:      10:9:16
Pre: File is already open.
Post: None
* Description:     This operator puts the plan name, calorie goal, and date in the fstream.
* Returns:				lhs (of the stream)
*************************************************************/
fstream & operator>> (fstream &lhs, DietPlan &rhs)
{
	char name[100];
	lhs.getline(name, 100);
	rhs.setName(name);
	int goalCalories = 0;
	lhs >> goalCalories;
	rhs.setGoalCalories(goalCalories);
	char eatLine[100];
	lhs.getline(eatLine, 100);
	char date[100];
	lhs.getline(date, 100);
	rhs.setDate(date);
	char eatSpace[2];
	lhs.getline(eatSpace, 2); // Get/eat the newline after the Date

	return lhs;
}

/*************************************************************
* Overloaded Operator: ostream &operator<<(ostream &lhs, const DietPlan &rhs)
* Date Last Modified:      10:9:16
Pre: None
Post: None
* Description:     This operator puts the plan name, calorie goal, and date in the outstream.
* Returns:				lhs (of the stream)
*************************************************************/
ostream &operator<<(ostream &lhs, DietPlan &rhs)
{
	lhs << rhs.getName() << endl;
	lhs << rhs.getGoalCalories() << endl;
	lhs << rhs.getDate() << endl;

	return lhs;
}

/*************************************************************
* Overloaded Operator: fstream & operator>> (fstream &lhs, FitnessPlan &rhs)
* Date Last Modified:      10:9:16
Pre: File is already open.
Post: None
* Description:     This operator puts the plan name, calorie goal, and date in the fstream.
* Returns:				lhs (of the stream)
*************************************************************/
fstream & operator>> (fstream &lhs, FitnessPlan &rhs)
{
	char name[100];
	lhs.getline(name, 100);
	rhs.setName(name);
	int goalCalories = 0;
	lhs >> goalCalories;
	rhs.setGoalCalories(goalCalories);
	char eatLine[100];
	lhs.getline(eatLine, 100);
	char date[100];
	lhs.getline(date, 100);
	rhs.setDate(date);
	char eatSpace[2];
	lhs.getline(eatSpace, 2); // Get the newline after the calories 

	return lhs;
}

/*************************************************************
* Overloaded Operator: ostream &operator<<(ostream &lhs, const FitnessPlan &rhs)
* Date Last Modified:      10:9:16
Pre:
Post:
* Description:     This operator puts the plan name, calorie goal, and date in the outstream.
* Returns:				lhs (of the stream)
*************************************************************/
ostream &operator<<(ostream &lhs, FitnessPlan &rhs)
{
	lhs << rhs.getName() << endl;
	lhs << rhs.getGoalBurnCalories() << endl;
	lhs << rhs.getDate() << endl;

	return lhs;
}

/************************************************************
Pre: 
Post:
* Description:     This function displays the options available to a user, via a switch statement optimized layout.
* Returns:
*************************************************************/
void AppWrapper::initmenu()
{
	cout << "What would you like to do today?" << endl;
	cout << "Enter an option by typing a number without parenthesis." << endl;
	cout << "(1) Load a Weekly Diet Plan." << endl;
	cout << "(2) Load a Weekly Fitness Plan." << endl;
	cout << "(3) Store a Weekly Diet Plan." << endl;
	cout << "(4) Store a Weekly Fitness Plan." << endl;
	cout << "(5) Display a Weekly Diet Plan." << endl;
	cout << "(6) Display a Weekly Fitness Plan." << endl;
	cout << "(7) Edit a Daily Diet Plan." << endl;
	cout << "(8) Edit a Daily Fitness Plan." << endl;
	cout << "(9) Save Your Plans and Exit." << endl;
	cout << "(10) Print out the Nike Symbol Again." << endl;

}

/************************************************************
Pre: dependent on other functions and overloaded operators. files are opened here.
Post: files must be closed that are opened
* Description:     This function runs the app, allowing the user to print, store, and load records. 
					Additionally, the user may exit and do special things...
* Returns:
*************************************************************/
void AppWrapper::runAppManager()
{
	int choice = 0;
	int exit_option = 0;
	int is_he_seriously_doing_this = 0;
	int he_is = 1;
	AppWrapper User1App;
	fstream inDP;
	fstream inFP;
	ofstream outDP;
	ofstream outFP;

	do
	{
		User1App.initmenu();

		cin >> choice;
		system("cls");

		switch (choice)
		{
		case 1: 
			inDP.open("dietPlans.txt");
			User1App.loadWeeklyDP(inDP, User1App.mDP);
			inDP.close();
			break;
		case 2:
			inFP.open("exercisePlans.txt");
			User1App.loadWeeklyFP(inFP, User1App.mFP);
			inFP.close();
			break;
		case 3:
			outDP.open("dietPlans.txt");
			User1App.storeWeeklyDP(outDP, User1App.mDP);
			outDP.close();
			break;
		case 4:
			outFP.open("exercisePlans.txt");
			User1App.storeWeeklyFP(outFP, User1App.mFP);
			outFP.close();
			break;
		case 5:
			User1App.dispWeeklyDP(User1App.mDP);
			break;
		case 6:
			User1App.dispWeeklyFP(User1App.mFP);
			break;
		case 7:
			User1App.editDailyDP(User1App.mDP);
			break;
		case 8:
			User1App.editDailyFP(User1App.mFP);
			break;
		case 9:
			exit_option = 9;
			cout << "Come Back to your App Soon, remember you paid brand name price for this!" << endl;
			outDP.open("dietPlans.txt");
			User1App.storeWeeklyDP(outDP, User1App.mDP);
			outDP.close();
			outFP.open("exercisePlans.txt");
			User1App.storeWeeklyFP(outFP, User1App.mFP);
			outFP.close();
			break;
		case 10://hahahahahaha
			he_is = is_he_seriously_doing_this;
			cout << "��������������������������������������������������" << endl;
			cout << "��������������������������������������������������" << endl;
			cout << "�������1�������������������������������������1����" << endl;
			cout << "������_�������������������������������1___1�������" << endl;
			cout << "�����__�������������������������1______�����������" << endl;
			cout << "����___�������������������1_______1���������������" << endl;
			cout << "���____1�����������11_________1�������������������" << endl;
			cout << "��_______11111____________������������������������" << endl;
			cout << "��____________________����������������������������" << endl;
			cout << "��_______________1��������������������������������" << endl;
			cout << "���__________1������������������������������������" << endl;
			cout << "��������������������������������������������������" << endl;
			cout << " " << endl;
			cout << "Don't you have other assignments to be grading, Collin?" << endl;
			cout << " " << endl;
			cout << " " << endl;
			break;
		default:
			cout << "Enter a number between 1 and 10 inclusive, stop trying to break the program." << endl; //haha
			cout << " " << endl;
			break;
		}
	} while (exit_option != 9);

}