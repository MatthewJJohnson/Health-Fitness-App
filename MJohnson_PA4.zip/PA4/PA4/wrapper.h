#pragma once

#include <iostream>
#include <fstream>
#include <string>

#include "fitness.h"
#include "diet.h"

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;

class AppWrapper
{
public:
	//constructor
	AppWrapper(DietPlan dp[7], FitnessPlan fp[7]);
	AppWrapper();

	//Menu and manager (public info)
	static void runAppManager(); //denoted static
	void initmenu();

	//store and load plans (public info)
	void loadDailyDP(fstream &filein, DietPlan &dplan);
	void loadWeeklyDP(fstream &filein, DietPlan dplan[]);
	void loadDailyFP(fstream &filein, FitnessPlan &fplan);
	void loadWeeklyFP(fstream &filein, FitnessPlan fplan[]);
	void storeDailyDP(ofstream &fileout, DietPlan &dplan);
	void storeWeeklyDP(ofstream &fileout, DietPlan dplan[]);
	void storeDailyFP(ofstream &fileout, FitnessPlan &fplan);
	void storeWeeklyFP(ofstream &fileout, FitnessPlan fplan[]);

	//edit and print plans (public info)
	void dispDailyDP(DietPlan &dplan);
	void dispWeeklyDP(DietPlan dplan[]);
	void dispDailyFP(FitnessPlan &fplan);
	void dispWeeklyFP(FitnessPlan fplan[]);
	void editDailyDP(DietPlan dplan[]);
	void editDailyFP(FitnessPlan fplan[]);


private:
	DietPlan mDP[7];
	FitnessPlan mFP[7];
};
//overloaded operators
fstream &operator>> (fstream &lhs, DietPlan &rhs);
ostream &operator<<(ostream &lhs,  DietPlan &rhs);
fstream &operator>> (fstream &lhs, FitnessPlan &rhs);
ostream &operator<<(ostream &lhs,  FitnessPlan &rhs);