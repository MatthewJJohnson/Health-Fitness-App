#pragma once

#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;

class FitnessPlan
{

public:
	//basic constructor
	FitnessPlan();
	FitnessPlan(FitnessPlan &copy); // shallow copy

	~FitnessPlan();

	//get
	string getDate() const;
	string getName() const;
	int getGoalBurnCalories() const;

	//set
	void setDate(const string newDate);
	void setName(const string &newName);
	void setGoalCalories(const int &newCalories);

	//edit and print plans (public info)
	FitnessPlan &FPplanEditor(FitnessPlan &newEditPlan);
	void printFitnessPlan(FitnessPlan &fplan);

private:
	int mGoalCalories;
	string mDate;
	string mName;

};

//fstream &operator>> (fstream &lhs, FitnessPlan &rhs); not needed until export 
ostream &operator<<(ostream &lhs, const FitnessPlan &rhs);