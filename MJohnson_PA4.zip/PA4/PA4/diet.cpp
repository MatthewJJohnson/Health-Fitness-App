#include "diet.h"

/************************************************************
Pre:
Post:
* Description:     This function is the default constructor for dietplan.
* Returns:
*************************************************************/
DietPlan::DietPlan()
{
	this->mDate = "";
	this->mName = "";
	this->mGoalCalories = 0;
}

/************************************************************
Pre:
Post:
* Description:     This function copies dietplans, it is the copy constructor.
* Returns:
*************************************************************/
DietPlan::DietPlan(DietPlan &copy)
{
	this->mDate = copy.getDate();
	this->mName = copy.mName;
	this->mGoalCalories = copy.mGoalCalories;
}

/************************************************************
Pre:
Post:
* Description:     This function is the dietplan destructor.
* Returns:
*************************************************************/
DietPlan::~DietPlan()
{

}

/************************************************************
Pre:
Post:
* Description:     This function gets the new date.
* Returns:
*************************************************************/
string DietPlan::getDate() const
{
	return this->mDate;
}

/************************************************************
Pre:
Post:
* Description:     This function gets the new name.
* Returns:
*************************************************************/
string DietPlan::getName() const
{
	return this->mName;
}

/************************************************************
Pre: 
Post:
* Description:     This function gets the new calories.
* Returns:
*************************************************************/
int DietPlan::getGoalCalories() const
{
	return this->mGoalCalories;
}

/************************************************************
Pre: 
Post:
* Description:     This function sets name to the newname string.
* Returns:
*************************************************************/
void DietPlan::setName(const string &newName)
{
	this->mName = newName;
}

/************************************************************
Pre: 
Post:
* Description:     This function sets date to the newdate string.
* Returns:
*************************************************************/
void DietPlan::setDate(const string newDate)
{
	this->mDate = newDate;
}

/************************************************************
Pre: 
Post:
* Description:     This function sets calories to the newcalorie value.
* Returns:				
*************************************************************/
void DietPlan::setGoalCalories(const int &newCalories)
{
	this->mGoalCalories = newCalories;
}

/*************************************************************
* Function: void DietPlan::printDietPlan(DietPlan &dplan)
* Date Last Modified:      10:9:16
Pre:
Post:
* Description:     This function asks for a new calorie goal.
* Returns:				newEditPlan
*************************************************************/
DietPlan &DietPlan::DPplanEditor(DietPlan &newEditPlan)
{
	int UserGoal;

	cout << "Please enter a New Calorie Goal: ";
	cin >> UserGoal;

	setGoalCalories(UserGoal);//make the change

	return newEditPlan;
}

/*************************************************************
* Function: void DietPlan::printDietPlan(DietPlan &dplan)
* Date Last Modified:      10:9:16
Pre:
Post:
* Description:     This function puts a plan in the outstream.
* Returns:				
*************************************************************/
void DietPlan::printDietPlan(DietPlan &dplan)
{
	cout << dplan;
}

/*************************************************************
* Overloaded Operator: ostream &operator<<(ostream &lhs, const DietPlan &rhs)
* Date Last Modified:      10:9:16
Pre:
Post:
* Description:     This operator puts the plan name, calorie goal, and date in the outstream.
* Returns:				lhs (of the stream)
*************************************************************/
ostream &operator<<(ostream &lhs, const DietPlan &rhs)
{
	lhs << "Daily Plan Name: " << rhs.getName() << endl;
	lhs << "Daily Calorie Goal: " << rhs.getGoalCalories() << endl;
	lhs << "Plan Date: " << rhs.getDate() << endl;

	return lhs;
}