#pragma once

#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;

class DietPlan
{

public:
	//basic constructor
	DietPlan();
	DietPlan(DietPlan &copy); // copy using shallow copy

	~DietPlan(); //destructor

	//get
	string getDate() const;
	string getName() const;
	int getGoalCalories() const;

	//set
	void setDate(const string newDate);
	void setName(const string &newName);
	void setGoalCalories(const int &newCalories);

	//edit and print plans (public info)
	DietPlan &DPplanEditor(DietPlan &newEditPlan);
	void printDietPlan(DietPlan & dplan);

private:
	int mGoalCalories;
	string mDate;
	string mName;

};

//fstream &operator>> (fstream &lhs, DietPlan &rhs); not needed until export 
ostream &operator<<(ostream &lhs, const DietPlan &rhs);